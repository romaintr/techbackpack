
$( document ).ready(function() {

	$( "p" ).on( "click", function() {

		if ($(this).hasClass('red')){
			$(this).removeClass('red');
		}else{
  			$(this).addClass('red');
  		}
	});

	if(document.domain===clubmed.fr){
	  ga('create', 'UA-72747588-1', 'auto');
	  ga('send', 'pageview');
	}else{
	  ga('create', 'UA-72747588-2', 'auto');
	  ga('send', 'pageview');
	}

});

