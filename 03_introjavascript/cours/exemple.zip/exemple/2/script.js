//on insere du js
alert("test2");